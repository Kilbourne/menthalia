<div class="alm-drop-btn alm-repeater-options">
   <a href="javascript:void(0);" class="target"><i class="fa fa-cog"></i> <?php _e('Options', 'ajax-load-more'); ?></a>
	<div class="alm-dropdown">
	   <div class="alm-drop-inner">
   	   <ul>
   	      <li class="option-update"><a href="javascript:void(0);" title="<?php _e('Update Template from Database', 'ajax-load-more'); ?>"><i class="fa fa-download"></i> <?php _e('Update Template from Database', 'ajax-load-more'); ?></a></li>
   	      <li class="copy"><a href="javascript:void(0);" title="<?php _e('Copy Template Data', 'ajax-load-more'); ?>"><i class="fa fa-file"></i> <?php _e('Copy Template Data', 'ajax-load-more'); ?></a></li>
   	   </ul>
	   </div>
	</div>
</div>