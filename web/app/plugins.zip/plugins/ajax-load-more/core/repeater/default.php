<article <?php post_class('card'); ?>>
  
  	<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
  <div class="entry-summary">
  	<h2 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
    <?php the_excerpt(); ?>
  </div>
</article>